# Changelog

## 0.4.2 — 2026-10-28
- Package screen: a package already installed in the org shows a ticked (green) checkbox, a light green tile and no Install button; it can't be selected and *Select all* skips it. In the sidebar it shows the ✔ icon without a checkbox.

## 0.4.1 — 2026-10-28
- Built-in Reej list: ReejOrgInit updated to 1.0.0-3 (04tg8000000Xgi1AAC); added Generic PDF Generator 1.0.0-1 and Render Email Template 1.0.0-1 to the Reej group; Docs links to the GitHub repositories.

## 0.4.0 — 2026-10-27
- **Package screen** (editor tab): one tile per package, grouped by source (Reej, UnofficialSF, …), with installed status in the connected org, dependencies, post-install steps, Docs link and a per-tile Install button. Select all / Unselect all per group. A bottom bar shows the install order and installs the selection; tiles show live progress.
- **Run Setup** now opens the package screen for the connected org instead of asking for the org again (it only asks when no org is connected). Clicking *Packages* in the sidebar opens it too.
- Packages have a `source` (tile group) and an optional `url`; *Add Package* asks for the source.

## 0.3.1 — 2026-10-27
- The full Reej package list (ReejOrgInit, Flow Actions Base Pack, Flow Screen Components Base Pack, Datatable) is now built in and used by default when no catalog file is set — nothing to configure.
- Adding or removing a package while on the built-in list first saves an editable copy and makes it your catalog for all workspaces.

## 0.3.0 — 2026-10-27
- Fix: the Salesforce CLI was reported as "not found" (`sf version --json` has no status field). The CLI is now also looked for in its usual install folders, can be set with `reejFastOrg.sfPath`, and the real error is shown on hover.
- Packages are selected with **checkboxes** in the sidebar; ticking a package ticks its dependencies, unticking one unticks the packages that need it. New *Install Selected Packages*, *Select All*, *Clear Selection*.
- **Add Package to Catalog…**: paste an install link or a 04t Id, name it, pick its dependencies. *Remove from Catalog* on right-click.
- **Choose Package Catalog…**: use or create a catalog file, for all workspaces or this one.
- `deploy` post-install steps run from the SFDX project that contains the deployed folder.
- The sample catalog now holds the real UnofficialSF Flow Base Packs and Datatable.

## 0.2.0 — 2026-10-27
- Extension icon and activity-bar icon (Reej mark + cloud with a lightning bolt).
- ReejFastOrg sidebar: connected org, catalog packages with their install status in that org, authenticated orgs, last run, environment.
- Menus: title-bar buttons (Run Setup, Connect, Open Catalog, Refresh), inline and right-click actions on orgs and packages (install one package, use / open an org, open the Installed Packages page, copy the 04t Id), explorer and editor menus on `.reejfastorg/*.json` catalogs.

## 0.1.0 — 2026-10-27
- First version: connect to a Dev / Sandbox / Production / scratch org via the sf CLI (existing auth or browser login), pick packages from `.reejfastorg/packages.json`, install them in dependency order with post-install steps (permission sets, anonymous Apex, data tree import, deploy, any sf command).
