# Changelog

## 0.2.0 — 2026-10-27
- Extension icon and activity-bar icon (Reej mark + cloud with a lightning bolt).
- ReejFastOrg sidebar: connected org, catalog packages with their install status in that org, authenticated orgs, last run, environment.
- Menus: title-bar buttons (Run Setup, Connect, Open Catalog, Refresh), inline and right-click actions on orgs and packages (install one package, use / open an org, open the Installed Packages page, copy the 04t Id), explorer and editor menus on `.reejfastorg/*.json` catalogs.

## 0.1.0 — 2026-10-27
- First version: connect to a Dev / Sandbox / Production / scratch org via the sf CLI (existing auth or browser login), pick packages from `.reejfastorg/packages.json`, install them in dependency order with post-install steps (permission sets, anonymous Apex, data tree import, deploy, any sf command).
