import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { readCatalog, resolveInstallPlan } from './catalog';
import { getInstalledVersionIds, InstallSettings, runInstallPlan, summarize } from './installer';
import { describeOrg, kindLabel, listAuthenticatedOrgs, pickOrConnectOrg } from './orgs';
import { CancelledError, sf } from './sfCli';
import { FastOrgSidebar, Item } from './sidebar';
import { Catalog, ConnectedOrg, PackageResult } from './types';

const ORG_STATE_KEY = 'reejFastOrg.connectedOrg';
const LAST_RUN_KEY = 'reejFastOrg.lastRun';

interface LastRun { when: string; org: string; results: PackageResult[] }

let output: vscode.OutputChannel;
let statusBar: vscode.StatusBarItem;
let context: vscode.ExtensionContext;
let sidebar: FastOrgSidebar;

const log = (line: string) => output.appendLine(line);

export function activate(ctx: vscode.ExtensionContext) {
  context = ctx;
  output = vscode.window.createOutputChannel('ReejFastOrg Setup');
  statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 50);
  statusBar.command = 'reejFastOrg.runSetup';
  refreshStatusBar();
  statusBar.show();

  sidebar = new FastOrgSidebar({
    org: getOrg,
    catalog: catalogQuiet,
    orgs: () => listAuthenticatedOrgs({ cwd: workspaceDir() }),
    installedVersionIds: org => getInstalledVersionIds(org, { cwd: workspaceDir() }),
    sfVersion: async () => {
      const r = await sf<any>(['version'], { cwd: workspaceDir() });
      return String(r?.cliVersion ?? r?.version ?? '').replace('@salesforce/cli/', '') || undefined;
    },
    lastRun: () => context.workspaceState.get<LastRun>(LAST_RUN_KEY)
  });
  const view = vscode.window.createTreeView('reejFastOrg.home', { treeDataProvider: sidebar, showCollapseAll: true });

  // Redraw when the catalog file changes or the catalog setting moves.
  const watcher = vscode.workspace.createFileSystemWatcher('**/*.json');
  const onJson = (u: vscode.Uri) => { if (u.fsPath === catalogPath()) sidebar.refresh(); };
  watcher.onDidChange(onJson);
  watcher.onDidCreate(onJson);
  watcher.onDidDelete(onJson);

  const r = (id: string, fn: (...args: any[]) => Promise<unknown>) =>
    vscode.commands.registerCommand(id, (...args: any[]) => guard(() => fn(...args)));

  ctx.subscriptions.push(
    output,
    statusBar,
    view,
    watcher,
    vscode.workspace.onDidChangeConfiguration(e => { if (e.affectsConfiguration('reejFastOrg')) sidebar.refresh(); }),
    r('reejFastOrg.runSetup', runSetup),
    r('reejFastOrg.connectOrg', connectOrg),
    r('reejFastOrg.installPackages', installPackages),
    r('reejFastOrg.installPackage', installOnePackage),
    r('reejFastOrg.useOrg', useOrg),
    r('reejFastOrg.openOrg', openOrg),
    r('reejFastOrg.openInstalledPackages', (item?: Item) => openOrg(item, 'lightning/setup/ImportedPackage/home')),
    r('reejFastOrg.disconnectOrg', disconnectOrg),
    r('reejFastOrg.openCatalog', openCatalog),
    r('reejFastOrg.refresh', async () => sidebar.refresh(true)),
    r('reejFastOrg.copyVersionId', async (item?: Item) => {
      if (!item?.pkg) return;
      await vscode.env.clipboard.writeText(item.pkg.versionId);
      vscode.window.showInformationMessage(`ReejFastOrg: copied ${item.pkg.versionId}`);
    }),
    vscode.commands.registerCommand('reejFastOrg.showLog', () => output.show())
  );
}

export function deactivate() {}

/* ---------- helpers ---------- */

async function guard(fn: () => Promise<unknown>) {
  try {
    await fn();
  } catch (e: any) {
    if (e instanceof CancelledError) {
      log('Cancelled.');
      vscode.window.showWarningMessage('ReejFastOrg: cancelled.');
      return;
    }
    log(`ERROR: ${e.message}`);
    const pick = await vscode.window.showErrorMessage(`ReejFastOrg: ${e.message}`, 'Show Log');
    if (pick) output.show();
  }
}

function getOrg(): ConnectedOrg | undefined {
  return context.workspaceState.get<ConnectedOrg>(ORG_STATE_KEY);
}

async function setOrg(org: ConnectedOrg | undefined) {
  await context.workspaceState.update(ORG_STATE_KEY, org);
  refreshStatusBar();
  sidebar?.refresh();
}

function refreshStatusBar() {
  const org = getOrg();
  if (org) {
    statusBar.text = `$(cloud) ${org.alias ?? org.username}${org.kind === 'prod' ? ' $(warning)' : ''}`;
    statusBar.tooltip = `ReejFastOrg: ${org.orgName ?? ''} (${kindLabel(org.kind)})\n${org.username}\nClick to run setup`;
    statusBar.backgroundColor = org.kind === 'prod' ? new vscode.ThemeColor('statusBarItem.warningBackground') : undefined;
  } else {
    statusBar.text = '$(cloud) ReejFastOrg: no org';
    statusBar.tooltip = 'Click to connect an org and install packages';
    statusBar.backgroundColor = undefined;
  }
}

function settings(): InstallSettings {
  const c = vscode.workspace.getConfiguration('reejFastOrg');
  return {
    waitMinutes: c.get('waitMinutes', 30),
    securityType: c.get('securityType', 'AdminsOnly'),
    skipAlreadyInstalled: c.get('skipAlreadyInstalled', true),
    stopOnError: c.get('stopOnError', true)
  };
}

function workspaceDir(): string | undefined {
  return vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
}

function catalogPath(): string | undefined {
  const p = vscode.workspace.getConfiguration('reejFastOrg').get<string>('catalogPath', '.reejfastorg/packages.json');
  if (path.isAbsolute(p)) return p;
  const ws = workspaceDir();
  return ws ? path.join(ws, p) : undefined;
}

/** For the sidebar: never prompts. */
function catalogQuiet(): { catalog?: Catalog; error?: string; path?: string } {
  const file = catalogPath();
  if (!file || !fs.existsSync(file)) return { path: file };
  try {
    return { catalog: readCatalog(file), path: file };
  } catch (e: any) {
    return { error: e.message.split('\n')[0], path: file };
  }
}

async function loadCatalogInteractive(explicitFile?: string): Promise<Catalog | undefined> {
  let file = explicitFile ?? catalogPath();
  if (!file || !fs.existsSync(file)) {
    const choice = await vscode.window.showWarningMessage(
      file
        ? `No package catalog found at ${path.relative(workspaceDir() ?? '', file)}.`
        : 'Open a folder (or set reejFastOrg.catalogPath to an absolute path) to use a package catalog.',
      { modal: true },
      ...(file ? ['Create sample catalog'] : []),
      'Browse for catalog…'
    );
    if (choice === 'Create sample catalog' && file) {
      createSampleCatalog(file);
      await vscode.window.showTextDocument(vscode.Uri.file(file));
      vscode.window.showInformationMessage('ReejFastOrg: sample catalog created — replace the 04t Ids with your packages, then run the command again.');
      return undefined;
    }
    if (choice === 'Browse for catalog…') {
      const picked = await vscode.window.showOpenDialog({ canSelectMany: false, filters: { 'Package catalog': ['json'] } });
      if (!picked?.[0]) return undefined;
      file = picked[0].fsPath;
    } else {
      return undefined;
    }
  }
  const catalog = readCatalog(file);
  log(`Catalog: ${file} (${catalog.packages.length} package(s))`);
  return catalog;
}

function createSampleCatalog(file: string) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.copyFileSync(context.asAbsolutePath(path.join('resources', 'packages.sample.json')), file);
}

/* ---------- commands ---------- */

async function openCatalog() {
  const file = catalogPath();
  if (!file) {
    vscode.window.showWarningMessage('ReejFastOrg: open a folder first, or set reejFastOrg.catalogPath to an absolute path.');
    return;
  }
  if (!fs.existsSync(file)) {
    createSampleCatalog(file);
    sidebar.refresh();
  }
  await vscode.window.showTextDocument(vscode.Uri.file(file));
}

async function connectOrg(): Promise<ConnectedOrg | undefined> {
  output.show(true);
  log('\n--- Connect to an org ---');
  const org = await pickOrConnectOrg({ cwd: workspaceDir(), log });
  if (!org) return undefined;
  await setOrg(org);
  sidebar.refresh(true); // a new login changes the authenticated org list
  log(`Connected: ${org.target} — ${org.orgName ?? '?'} (${kindLabel(org.kind)}) ${org.instanceUrl ?? ''}`);
  vscode.window.showInformationMessage(`ReejFastOrg: using ${org.alias ?? org.username} (${kindLabel(org.kind)}).`);
  return org;
}

/** Sidebar: make an authenticated org the connected one. */
async function useOrg(item?: Item) {
  const o = item?.authOrg;
  if (!o) return connectOrg();
  const target = o.alias ?? o.username;
  const info = await vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title: `ReejFastOrg: checking ${target}…` },
    () => describeOrg(target, o.isScratch, { cwd: workspaceDir(), log })
  );
  const org: ConnectedOrg = { target, username: o.username, alias: o.alias, instanceUrl: info.instanceUrl ?? o.instanceUrl, orgName: info.orgName, kind: info.kind };
  await setOrg(org);
  log(`Connected: ${org.target} — ${org.orgName ?? '?'} (${kindLabel(org.kind)})`);
}

async function disconnectOrg() {
  await setOrg(undefined);
}

/** Opens the org (or one of its pages) in the browser. */
async function openOrg(item?: Item, pagePath?: string) {
  const target = item?.authOrg ? item.authOrg.alias ?? item.authOrg.username : getOrg()?.target;
  if (!target) return connectOrg();
  const args = ['org', 'open', '--target-org', target, '--url-only'];
  if (pagePath) args.push('--path', pagePath);
  const r = await sf<any>(args, { cwd: workspaceDir() });
  if (r?.url) await vscode.env.openExternal(vscode.Uri.parse(r.url));
}

async function runSetup() {
  const current = getOrg();
  let org: ConnectedOrg | undefined = current;
  if (current) {
    const pick = await vscode.window.showQuickPick(
      [
        { label: `$(check) Use ${current.alias ?? current.username}`, description: `${current.orgName ?? ''} · ${kindLabel(current.kind)}`, keep: true },
        { label: '$(arrow-swap) Choose another org…', keep: false }
      ],
      { title: 'ReejFastOrg Setup — 1/3 Connect to an org', ignoreFocusOut: true }
    );
    if (!pick) return;
    if (!pick.keep) org = await connectOrg();
  } else {
    org = await connectOrg();
  }
  if (!org) return;
  await installPackages();
}

/** Sidebar: install one package (plus its missing dependencies). */
async function installOnePackage(item?: Item) {
  if (!item?.pkg) return installPackages();
  await installPackages(undefined, [item.pkg.id]);
}

/**
 * Steps 2 and 3. `arg` is the catalog Uri when called from the explorer / editor menus.
 * `preselected` skips the picker (sidebar single-package install).
 */
async function installPackages(arg?: unknown, preselected?: string[]) {
  let org = getOrg();
  if (!org) {
    org = await connectOrg();
    if (!org) return;
  }

  const explicitFile = arg instanceof vscode.Uri ? arg.fsPath : undefined;
  const catalog = await loadCatalogInteractive(explicitFile);
  if (!catalog) return;

  let selectedIds = preselected;
  if (!selectedIds) {
    // 2/3 — choose packages
    const applicable = catalog.packages.filter(p => !p.orgTypes?.length || p.orgTypes.includes(org!.kind));
    const hidden = catalog.packages.length - applicable.length;
    if (!applicable.length) {
      vscode.window.showWarningMessage(`ReejFastOrg: no package in the catalog applies to a ${kindLabel(org.kind)} org.`);
      return;
    }
    const sorted = [...applicable].sort((a, b) => (a.order ?? 1e9) - (b.order ?? 1e9));
    const picks = await vscode.window.showQuickPick(
      sorted.map(p => ({
        label: p.name,
        description: [p.versionId, p.requiresKey ? '$(key)' : '', p.postInstall?.length ? `$(gear) ${p.postInstall.length} post-install` : '']
          .filter(Boolean).join('  '),
        detail: [p.description, p.dependsOn?.length ? `Requires: ${p.dependsOn.join(', ')}` : ''].filter(Boolean).join(' — ') || undefined,
        picked: !!p.default,
        id: p.id
      })),
      {
        title: `ReejFastOrg Setup — 2/3 Packages to install in ${org.alias ?? org.username}`,
        placeHolder: `Select packages${hidden ? ` (${hidden} hidden: not for ${kindLabel(org.kind)} orgs)` : ''}`,
        canPickMany: true,
        matchOnDescription: true,
        matchOnDetail: true,
        ignoreFocusOut: true
      }
    );
    if (!picks?.length) return;
    selectedIds = picks.map(p => p.id);
  }

  const { ordered, addedDeps } = resolveInstallPlan(catalog.packages, selectedIds);
  const notAllowed = ordered.filter(p => p.orgTypes?.length && !p.orgTypes.includes(org!.kind));
  if (notAllowed.length) {
    throw new Error(`Not allowed on ${kindLabel(org.kind)} orgs: ${notAllowed.map(p => p.name).join(', ')}`);
  }

  // 3/3 — confirm
  const planText = ordered
    .map((p, i) => `${i + 1}. ${p.name}${addedDeps.includes(p) ? ' (dependency)' : ''}${p.postInstall?.length ? ` + ${p.postInstall.length} post-install step(s)` : ''}`)
    .join('\n');
  const isProd = org.kind === 'prod';
  const confirm = await vscode.window.showWarningMessage(
    `${isProd ? '⚠ PRODUCTION ORG ⚠\n' : ''}Install ${ordered.length} package(s) in ${org.alias ?? org.username}${org.orgName ? ` (${org.orgName})` : ''}?`,
    { modal: true, detail: planText },
    isProd ? 'Install in Production' : 'Install'
  );
  if (!confirm) return;

  const keys = new Map<string, string>();
  for (const p of ordered.filter(p => p.requiresKey && !p.installationKey)) {
    const key = await vscode.window.showInputBox({
      title: `Installation key — ${p.name}`,
      password: true,
      ignoreFocusOut: true,
      validateInput: v => (v ? undefined : 'Required')
    });
    if (!key) return;
    keys.set(p.id, key);
  }

  output.show(true);
  let results: PackageResult[];
  try {
    results = await vscode.window.withProgress(
      { location: vscode.ProgressLocation.Notification, title: `ReejFastOrg → ${org.alias ?? org.username}`, cancellable: true },
      (progress, token) =>
        runInstallPlan(ordered, { org: org!, catalog, settings: settings(), keys, projectDir: workspaceDir(), progress, token, log })
    );
  } finally {
    sidebar.invalidateInstalled(org.target);
  }

  await context.workspaceState.update(LAST_RUN_KEY, { when: new Date().toISOString(), org: org.alias ?? org.username, results } as LastRun);
  sidebar.refresh();

  const summary = summarize(results);
  log(`\n=== Summary ===\n${summary}`);
  const failed = results.filter(r => r.status === 'failed').length;
  const done = results.filter(r => r.status === 'installed').length;
  const skipped = results.filter(r => r.status === 'skipped').length;
  const msg = `ReejFastOrg: ${done} installed, ${skipped} skipped, ${failed} failed.`;
  const action = await (failed ? vscode.window.showErrorMessage : vscode.window.showInformationMessage)(msg, 'Show Log');
  if (action) output.show();
}
