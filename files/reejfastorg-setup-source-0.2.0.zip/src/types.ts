export type OrgKind = 'dev' | 'sandbox' | 'prod' | 'scratch' | 'unknown';

export interface ConnectedOrg {
  /** Alias if any, otherwise username. Used as --target-org. */
  target: string;
  username: string;
  alias?: string;
  instanceUrl?: string;
  orgName?: string;
  kind: OrgKind;
}

export type PostInstallStep =
  | { type: 'permset'; name: string | string[]; label?: string; continueOnError?: boolean }
  | { type: 'apex'; file: string; label?: string; continueOnError?: boolean }
  | { type: 'dataTree'; plan: string; label?: string; continueOnError?: boolean }
  | { type: 'deploy'; path: string; label?: string; continueOnError?: boolean }
  | { type: 'sf'; args: string[]; label?: string; continueOnError?: boolean };

export interface CatalogPackage {
  /** Stable key used by dependsOn. */
  id: string;
  name: string;
  description?: string;
  /** Subscriber package version Id (04t...). */
  versionId: string;
  /** Tie-breaker for install order (lower first). Dependencies always come first. */
  order?: number;
  dependsOn?: string[];
  /** Pre-selected in the picker. */
  default?: boolean;
  /** Ask the user for the installation key at install time. */
  requiresKey?: boolean;
  /** Installation key stored in the catalog (avoid committing secrets). */
  installationKey?: string;
  /** Restrict the package to some org kinds. Omitted = all. */
  orgTypes?: OrgKind[];
  postInstall?: PostInstallStep[];
}

export interface Catalog {
  packages: CatalogPackage[];
  /** Folder of the catalog file — relative step paths resolve from here. */
  baseDir: string;
  source: string;
}

export type StepStatus = 'ok' | 'failed' | 'skipped';
export type PackageStatus = 'installed' | 'skipped' | 'failed' | 'not run';

export interface PackageResult {
  pkg: CatalogPackage;
  status: PackageStatus;
  error?: string;
  steps: { label: string; status: StepStatus; error?: string }[];
}
