import { spawn } from 'child_process';
import * as vscode from 'vscode';

export class SfError extends Error {
  constructor(message: string, public readonly output?: any) {
    super(message);
    this.name = 'SfError';
  }
}

export class CancelledError extends Error {
  constructor() {
    super('Cancelled by user');
    this.name = 'CancelledError';
  }
}

export interface SfRunOptions {
  cwd?: string;
  token?: vscode.CancellationToken;
  log?: (line: string) => void;
  /** Argument values to mask in the log (installation keys, …). */
  secrets?: string[];
}

function quoteForWindowsShell(arg: string): string {
  if (arg === '') return '""';
  return /[\s"&|<>^()%!]/.test(arg) ? `"${arg.replace(/"/g, '\\"')}"` : arg;
}

/**
 * Runs `sf <args> --json` and returns the parsed `result`.
 * Rejects with SfError when the CLI reports a non-zero status.
 */
export function sf<T = any>(args: string[], opts: SfRunOptions = {}): Promise<T> {
  const fullArgs = [...args, '--json'];
  const shown = fullArgs
    .map(a => (opts.secrets?.includes(a) ? '********' : a))
    .join(' ');
  opts.log?.(`$ sf ${shown}`);

  return new Promise<T>((resolve, reject) => {
    if (opts.token?.isCancellationRequested) return reject(new CancelledError());

    const isWin = process.platform === 'win32';
    const env = {
      ...process.env,
      SF_AUTOUPDATE_DISABLE: 'true',
      SF_JSON_TO_STDOUT: 'true',
      SF_USE_PROGRESS_BAR: 'false',
      FORCE_COLOR: '0',
      NO_COLOR: '1'
    };
    const child = isWin
      ? spawn('sf', fullArgs.map(quoteForWindowsShell), { cwd: opts.cwd, env, shell: true, windowsHide: true })
      : spawn('sf', fullArgs, { cwd: opts.cwd, env });

    let stdout = '';
    let stderr = '';
    let cancelled = false;
    const sub = opts.token?.onCancellationRequested(() => {
      cancelled = true;
      child.kill();
    });

    child.stdout.on('data', d => (stdout += d.toString()));
    child.stderr.on('data', d => (stderr += d.toString()));

    child.on('error', (err: NodeJS.ErrnoException) => {
      sub?.dispose();
      if (err.code === 'ENOENT') {
        reject(new SfError('Salesforce CLI (sf) was not found on PATH. Install it from https://developer.salesforce.com/tools/salesforcecli and restart VS Code.'));
      } else {
        reject(new SfError(err.message));
      }
    });

    child.on('close', code => {
      sub?.dispose();
      if (cancelled) return reject(new CancelledError());

      const start = stdout.indexOf('{');
      if (start < 0) {
        const msg = (stderr || stdout).trim();
        if (/not recognized|command not found/i.test(msg)) {
          return reject(new SfError('Salesforce CLI (sf) was not found on PATH. Install it and restart VS Code.'));
        }
        return reject(new SfError(msg || `sf exited with code ${code}`));
      }

      let json: any;
      try {
        json = JSON.parse(stdout.slice(start));
      } catch {
        return reject(new SfError(`Could not parse sf output: ${stdout.slice(0, 500)}`));
      }

      for (const w of json.warnings ?? []) opts.log?.(`  ⚠ ${w}`);

      if (json.status !== 0) {
        return reject(new SfError(json.message || json.name || `sf exited with status ${json.status}`, json));
      }
      resolve(json.result as T);
    });
  });
}
