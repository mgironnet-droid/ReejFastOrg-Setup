# Changelog

## 0.3.0 — 2026-10-27
- Fix: the Salesforce CLI was reported as "not found" (`sf version --json` has no status field). The CLI is now also looked for in its usual install folders, can be set with `reejFastOrg.sfPath`, and the real error is shown on hover.
- Packages are selected with **checkboxes** in the sidebar; ticking a package ticks its dependencies, unticking one unticks the packages that need it. New *Install Selected Packages*, *Select All*, *Clear Selection*.
- **Add Package to Catalog…**: paste an install link or a 04t Id, name it, pick its dependencies. *Remove from Catalog* on right-click.
- **Choose Package Catalog…**: use or create a catalog file, for all workspaces or this one.
- `deploy` post-install steps run from the SFDX project that contains the deployed folder.
- The sample catalog now holds the real UnofficialSF Flow Base Packs and Datatable.

## 0.2.0 — 2026-10-27
- Extension icon and activity-bar icon (Reej mark + cloud with a lightning bolt).
- ReejFastOrg sidebar: connected org, catalog packages with their install status in that org, authenticated orgs, last run, environment.
- Menus: title-bar buttons (Run Setup, Connect, Open Catalog, Refresh), inline and right-click actions on orgs and packages (install one package, use / open an org, open the Installed Packages page, copy the 04t Id), explorer and editor menus on `.reejfastorg/*.json` catalogs.

## 0.1.0 — 2026-10-27
- First version: connect to a Dev / Sandbox / Production / scratch org via the sf CLI (existing auth or browser login), pick packages from `.reejfastorg/packages.json`, install them in dependency order with post-install steps (permission sets, anonymous Apex, data tree import, deploy, any sf command).
